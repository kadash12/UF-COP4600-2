#ifndef P1_TEST_UTIL
#define P1_TEST_UTIL

#include <stdbool.h>

bool is_set_valid(int pid_to_modify, int old_tag, int new_tag);

#endif  // P1_TEST_UTIL