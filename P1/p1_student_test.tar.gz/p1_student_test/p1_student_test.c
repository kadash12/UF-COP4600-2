#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// p1 test utility library
#include "p1_test_util.h"
// tests used in test suite
#include "tests.h"
// other helper functions
#include "util.h"

// project includes (files from your tags folder)
#include "tags/harness.h"
#include "tags/tags.h"

#define PATH_BUF_SIZE 1024

int run_single_test(int pid_to_modify, int new_tag, int run_as_superuser) {
    bool error = false;

    pid_t current_pid = getpid();

    printf("INFO : pid of current process is : %d\n", current_pid);

    if (pid_to_modify == 0) pid_to_modify = current_pid;
    printf("INFO : pid to modify for syscalls is : %d\n", pid_to_modify);

    if (run_as_superuser) {
        if (!re_elevate_privileges())
            printf("SEVERE_RUNTIME_FAILURE : re-elevate permissions failed.\n");
    } else {
        if (!drop_privileges())
            printf("SEVERE_RUNTIME_FAILURE : drop permissions failed.\n");
    }

    // check if pid exists
    int kill_ret = kill(pid_to_modify, 0);
    if (kill_ret == -1 && errno == ESRCH) {
        printf("\n");
        printf("WARNING : a process with pid of %d does not exist!\n",
               pid_to_modify);
    }

    printf("\n");

    int old_tag = get_tag(pid_to_modify);
    printf("INFO : return value from get_tag, before running set_tag : %d\n",
           old_tag);

    int set_tag_ret = set_tag(pid_to_modify, new_tag);
    printf("INFO : return value from set_tag : %d\n", set_tag_ret);

    bool valid = is_set_valid(pid_to_modify, old_tag, new_tag);

    int get_tag_ret = get_tag(pid_to_modify);
    printf("INFO : return value from get_tag, after running set_tag : %d\n",
           get_tag_ret);

    printf("\n");

    if (valid) {
        if (set_tag_ret == -1) {
            error = true;
            printf(
                "ERROR : set_tag systemcall failed (returned -1) when it "
                "should have passed.\n");
        }

        if (get_tag_ret != new_tag) {
            error = true;
            printf("ERROR : either get_tag failed or set_tag failed.\n");
        }

    } else {
        if (set_tag_ret != -1) {
            error = true;
            printf("ERROR : set_tag systemcall invalid result.\n");
        }

        if (old_tag != new_tag) {
            if (get_tag_ret != old_tag) {
                error = true;
                printf(
                    "ERROR : either set_tag set a tag when not allowed to, "
                    "or "
                    "get_tag failed.\n");
            }
        }
    }

    return error ? -1 : 0;
}

int run_test_suite() {
    printf(
        "This test suite will perform unit tests to check the "
        "correctness of your solution.\n\n");

    int num_tests = 6;
    int num_tests_passed = 0;

    test_1() && ++num_tests_passed;
    test_2() && ++num_tests_passed;
    test_3() && ++num_tests_passed;
    test_4() && ++num_tests_passed;
    test_5() && ++num_tests_passed;
    test_6() && ++num_tests_passed;

    if (num_tests == num_tests_passed)
        printf("ALL %d TESTS PASSED\n", num_tests);
    else
        printf("%d TESTS FAILED\n", num_tests - num_tests_passed);

    return num_tests == num_tests_passed;
}

int run_interactive() {
    printf(
        "This program tests the get_tag and set_tag system call with arbitrary "
        "user inputted values and checks if the result is valid.\n");
    printf("If no errors are outputted then the result is valid.\n");
    printf("Press Ctrl+C at any time to exit.\n\n");

    int pid_to_modify;
    int old_tag;
    int new_tag;
    int run_as_superuser;

    while (true) {
        printf("Enter pid to modify (enter 0 to modify current process) : ");
        scanf("%d", &pid_to_modify);
        printf("Enter new tag : ");
        scanf("%d", &new_tag);
        printf("Execute as superuser? (enter 0 (false) or 1 (true)) : ");
        scanf("%d", &run_as_superuser);

        run_single_test(pid_to_modify, new_tag, run_as_superuser);

        printf("Running again ...\n\n");
    }
}

int test_main(int argc, char** argv) {
    int mode;
    if (argc == 1) {
        printf("Select mode (enter 0 (interactive) or 1 (test suite): ");
        scanf("%d", &mode);
        printf("\n");
        switch (mode) {
            case 0:
                return run_interactive();
            case 1:
                return run_test_suite();
        }
    } else if (argc == 4) {
        return run_single_test(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]));
    } else {
        printf("Invalid number of arguments, check README.\n");
    }
}

int main(int argc, char** argv) {
    if (getuid() != 0 || geteuid() != 0) {
        printf("Attempting to elevate to superuser ...\n\n");
        // get path to executable
        char buf[PATH_BUF_SIZE];
        int path_str_len = readlink("/proc/self/exe", buf, PATH_BUF_SIZE);
        buf[path_str_len] = '\0';
        int argv_len = 0;
        for (unsigned int i = 0; i < argc; i++) {
            argv_len += strlen(argv[i]);
        }
        char path_str[path_str_len + 5 + argv_len + (argc - 1)];
        // concatenate "sudo " with path
        strcpy(path_str, "sudo ");
        strcat(path_str, buf);
        // preserve command line arguments
        for (unsigned int i = 1; i < argc; i++) {
            strcat(path_str, " ");
            strcat(path_str, argv[i]);
        }
        // re-execute
        int ret = system(path_str);
        return ret;
    } else {
        return test_main(argc, argv);
    }
}