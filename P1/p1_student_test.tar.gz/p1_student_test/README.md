# P1 CLI Tester

This tool will test P1 for these things:

- Any process that does not have a parent shall have a tag of 0x00000000.
- All child processes shall inherit the tag of their parent process (all 32 bits of it).
- A process running as the superuser may read and write the tag of any process (all 32 bits of it, but it still
cannot set the MSB to 1).
- A user process has read-only access to the tag of any process.
- A user process may decrease its own level, but not increase it.
- A user process may reset a bit in its tag's bitmap to zero but not set a bit.

This tool will not check if the manpage were installed successfully. Ensure that you install the manpages into the correct locations and that they are formatted properly!

It uses the library functions, not the harness functions.
Therefore it will not test your harness functions!
Ensure that they work before submitting P1!

Inside the util.h/util.c files in this folder, there are harness_get_tag and harness_set_tag functions defined. These functions should return the same value as get_tag and set_tag respectively, but are implemented using the harness functions. This is provided to make it clear how the harness functions will be used.

## Compile

To compile, you'll first need to add your tags folder into this folder.

You will then have:

- p1_student_test (folder this file is in)
    - tags (your folder)
    - README.md (this file)
    - other testing files

Once all correct, run `make` in this folder!

Note: this tester is expecting that the Makefile in the tags folder is present and is functional!

If this tester fails to compile, check your Makefile!

## Tester Usage

This CLI tester can be used by running `sudo ./p1_student_test` in this folder.

When used with no arguments, it asks if you want to run the tester in the interactive or the test suite mode.

In interactive mode, it provides a text based user interface loop that prompts the user
for a pid, a new tag, and whether or not to execute the system call as a superuser.

In test suite mode, it runs automated tests and will output the results of the tests, and errors if present.

Note: The tester will check for the following things only in test suite mode, not in interactive mode:

- Any process that does not have a parent shall have a tag of "0x00000000".
- All child processes shall inherit the tag of their parent process (all 32 bits of it).

When used with 3 arguments, ie `sudo ./p1_student_test 0 5 1`, the CLI tester runs in command mode
where it runs once without blocking. The order of the arguments is `pid, new_tag, superuser (0 (false) or 1 (true))`. When in this mode, the program will return 0 on test success and -1 on test failure.
In this mode, you must run the tester with sudo. This mode is good for writing your own tests using bash if desired.

For the interactive mode, to use the pid of the currently running process, enter a pid of 0. This is just for convenience of this tester! Your system call functions should not do anything special when the pid passed in is 0.
This won't work with the 3 arguments (command) mode, since the process terminates after it runs once.