#ifndef P1_TESTS
#define P1_TESTS

#include <stdbool.h>

void test_status_print(bool test_status);

bool test_1();
bool test_2();
bool test_3();
bool test_4();
bool test_5();
bool test_6();

#endif  // P1_TESTS