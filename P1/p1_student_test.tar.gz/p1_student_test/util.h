#ifndef UTIL
#define UTIL

#include <stdbool.h>

int harness_get_tag(int pid);

int harness_set_tag(int pid, int new_tag);

bool drop_privileges();

bool re_elevate_privileges();

#endif  // UTIL