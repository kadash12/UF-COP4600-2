#pragma GCC diagnostic ignored "-Woverflow"

#include "tests.h"

#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// p1 test utility library
#include "p1_test_util.h"
// other helper functions
#include "util.h"

// project includes (files from your tags folder)
#include "tags/tags.h"

void test_status_print(bool test_status) {
    if (test_status)
        printf("PASS\n\n");
    else
        printf("FAIL\n\n");
}

bool check_test_status(int pid_to_modify, int new_tag) {
    bool error = false;

    int old_tag = get_tag(pid_to_modify);

    int set_tag_ret = set_tag(pid_to_modify, new_tag);

    bool valid = is_set_valid(pid_to_modify, old_tag, new_tag);

    int get_tag_ret = get_tag(pid_to_modify);

    if (valid) {
        if (set_tag_ret == -1) {
            error = true;
            printf(
                "ERROR : set_tag systemcall failed (returned -1) when it "
                "should have passed.\n");
        }

        if (get_tag_ret != new_tag) {
            error = true;
            printf("ERROR : either get_tag failed or set_tag failed.\n");
        }

    } else {
        if (set_tag_ret != -1) {
            error = true;
            printf("ERROR : set_tag systemcall invalid result.\n");
        }

        if (old_tag != new_tag) {
            if (get_tag_ret != old_tag) {
                error = true;
                printf(
                    "ERROR : either set_tag set a tag when not allowed to, "
                    "or "
                    "get_tag failed.\n");
            }
        }
    }

    return !error;
}

bool test_1() {
    printf(
        "TESTING : Any process that does not have a parent shall have a tag of "
        "0x00000000.\n");

    bool test_status = true;

    test_status = get_tag(1) == 0;

    test_status_print(test_status);
    return test_status;
}

bool test_2() {
    printf(
        "TESTING : All child processes shall inherit the tag of their parent "
        "process (all 32 bits of it).\n");

    bool test_status = true;

    int current_pid = getpid();

    if (!re_elevate_privileges())
        printf("SEVERE_RUNTIME_FAILURE : re-elevate permissions failed.\n");

    int tag = 4600;
    int set_tag_ret = set_tag(current_pid, tag);
    int child_pid = fork();
    test_status = set_tag_ret != -1 && get_tag(child_pid) == tag;

    kill(child_pid, SIGKILL);

    test_status_print(test_status);
    return test_status;
}

bool test_3() {
    printf(
        "TESTING : A user process has read-only access to the tag of any "
        "process.\n");

    bool test_status = true;
    bool set_valid = false;

    if (!drop_privileges())
        printf("SEVERE_RUNTIME_FAILURE : drop permissions failed.\n");

    int child_pid = fork();

    int old_tag = get_tag(child_pid);
    int new_tag = 0;

    test_status = check_test_status(child_pid, new_tag) && test_status;

    kill(child_pid, SIGKILL);

    test_status_print(test_status);
    return test_status;
}

bool test_4() {
    printf(
        "TESTING : A process running as the superuser may read and write the "
        "tag of any process (all 32 bits of it, but it still cannot set the "
        "MSB to 1).\n");

    bool test_status = true;

    if (!re_elevate_privileges())
        printf("SEVERE_RUNTIME_FAILURE : re-elevate permissions failed.\n");

    int child_pid = fork();

    int new_tag = 4600;
    test_status = check_test_status(child_pid, new_tag);

    new_tag = INT_MAX + 1;
    test_status = check_test_status(child_pid, new_tag) && test_status;

    kill(child_pid, SIGKILL);

    test_status_print(test_status);
    return test_status;
}

bool test_5() {
    printf(
        "TESTING: A user process may decrease its own level, but not increase "
        "it.\n");

    bool test_status = true;

    int current_pid = getpid();

    if (!re_elevate_privileges())
        printf("SEVERE_RUNTIME_FAILURE : re-elevate permissions failed.\n");

    int new_tag = 0b011;
    test_status = check_test_status(current_pid, new_tag);

    if (!drop_privileges())
        printf("SEVERE_RUNTIME_FAILURE : drop permissions failed.\n");

    new_tag = 0b001;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    new_tag = 0b101;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    new_tag = 0b011;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    test_status_print(test_status);
    return test_status;
}

bool test_6() {
    printf(
        "TESTING : A user process may reset a bit in its tag's bitmap to zero "
        "but not set a bit.\n");

    bool test_status = true;

    int current_pid = getpid();

    if (!re_elevate_privileges())
        printf("SEVERE_RUNTIME_FAILURE : re-elevate permissions failed.\n");

    int new_tag = 0b1100;
    test_status = check_test_status(current_pid, new_tag);

    if (!drop_privileges())
        printf("SEVERE_RUNTIME_FAILURE : drop permissions failed.\n");

    new_tag = 0b1000;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    new_tag = 0b1001;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    new_tag = 0b0000;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    new_tag = 0b1100;
    test_status = check_test_status(current_pid, new_tag) && test_status;

    test_status_print(test_status);
    return test_status;
}