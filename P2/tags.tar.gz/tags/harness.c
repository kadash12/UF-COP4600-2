#include <sys/syscall.h>
#include <unistd.h>
#include <stdlib.h>

#include "./harness.h"

int* retrieve_set_tag_params(int pid, int new_tag) {
    int* arr = (int*)malloc(4 * sizeof(int));
    arr[0] = 335;
    arr[1] = 2;
    arr[2] = pid;
    arr[3] = new_tag;
    return arr;
}

int* retrieve_get_tag_params(int pid) {
    int* arr = (int*)malloc(3 * sizeof(int));
    arr[0] = 336;
    arr[1] = 1;
    arr[2] = pid;
    return arr;
}

int interpret_set_tag_result(int ret_value) {
    return ret_value;
}

int interpret_get_tag_result(int ret_value) {
    return ret_value;
}