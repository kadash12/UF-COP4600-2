#ifndef HARNESS_H
#define HARNESS_H

int* retrieve_set_tag_params(int pid, int new_tag);

int* retrieve_get_tag_params(int pid);

int interpret_set_tag_result(int ret_value);

int interpret_get_tag_result(int ret_value);

#endif