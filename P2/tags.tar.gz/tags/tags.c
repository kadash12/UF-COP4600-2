#include <sys/syscall.h>
#include <unistd.h>

#include "./tags.h"

int set_tag(int pid, int new_tag) {
    return syscall(335, pid, new_tag);
}

int get_tag(int pid) {
    return syscall(336, pid);
}