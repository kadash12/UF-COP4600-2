#ifndef TAGS_H
#define TAGS_H

int set_tag(int pid, int new_tag);

int get_tag(int pid);

#endif